import java.util.Scanner;

public class exer1for {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		
		for (int i = 0; i <=4;i++) {
			System.out.println("Insira o numero");
			int numero = input.nextInt();
			if(numero % 2 ==0) {
				System.out.println("numero par");
				
			} else { System.out.println("Numero impar");
				
			
		}
		
		
		
		
		
		
	}

	}
}
