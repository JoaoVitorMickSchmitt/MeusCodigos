import java.util.Scanner;

public class exerRevisao2 {

	public static void main(String[] args) {
		
	
//		Escreva um algoritmo que imprima o n�mero 2, 5, 8, 11, 14 ...  at� o n�mero 5 mil
		
		Scanner  input =  new Scanner(System.in);
		
		for (int i = 2; i <= 5000; i = i + 3 ) {
			System.out.println( i );
			
			
			
		}
		
		
		
		
		
		

	}

}
