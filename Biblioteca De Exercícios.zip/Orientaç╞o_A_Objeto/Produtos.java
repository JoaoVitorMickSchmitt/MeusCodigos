package Orienta��o_A_Objeto;

public class Produtos {

//	produto1: Produto
//	nome = �Caderno�
//	descricao = �Caderno em espiral tamanho m�dio�
//	precoUnitario = 4,50
//	desconto = 15

	 String nome;
	 Str
	

	
}
