package Orienta��o_A_Objeto;

public class mercado1 {

}
