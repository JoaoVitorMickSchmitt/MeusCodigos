package Orienta��o_A_Objeto;

public class Exer2 {

}
