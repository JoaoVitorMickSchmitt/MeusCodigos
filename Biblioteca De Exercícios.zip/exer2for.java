import java.util.Scanner;

public class exer2for {

	public static void main(String[] args) {
	
		for (int numero = 0; numero <=21; numero++) {
			if(numero >=0 && numero <=20 && numero %2 ==0 ) {
				
			System.out.println(numero);
		}
		
		
		
		
		

	}

}
}