
public class area {

	public static void main(String[] args) {
		
		
		int altura = 1;
		int base = 2;
		int area;
		int perimetro;
		
		area = base * altura;
		perimetro = (base * 2) + (altura * 2);
		
		System.out.println(" a area do retangulo �: " + area + " e o perimetro �: " + perimetro);
	}
	

}
