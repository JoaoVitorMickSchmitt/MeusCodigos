
public class meusegundoprogramajavacerto {

	public static void main(String[] args) {
    
		System.out.println("Hellow World");
	int numeroUm = 1; 
	int numeroDois = 2;
	int numeroTres = 3;
	int numeroQuatro  = 1;	
	int numero  ; 
	System.out.println((numeroUm + numeroDois) * numeroQuatro);
	
	
	String nome = "joao";
	String sobrenome = "vitor";
			
	System.out.println("seu nome �:" +nome + " " +sobrenome);
	
	
	
	
	}

}
