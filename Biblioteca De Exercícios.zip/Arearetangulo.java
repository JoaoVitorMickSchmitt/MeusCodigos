import java.util.Scanner;

public class Arearetangulo {

	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		System.out.println("insira sua altura");
		double altura = input.nextDouble();

		System.out.println(altura + " metros");
		
	}

}
