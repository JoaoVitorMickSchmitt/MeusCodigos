import java.util.Scanner;

public class JoaoVitorMickSchmitt_2 {

	public static void main(String[] args) {
			Scanner input  = new Scanner(System.in);
			
			System.out.println(" escreva o valor do 1 lado");
			double lado1 = input.nextDouble();
		
			System.out.println(" escreva o valor do 2 lado");
			double lado2 = input.nextDouble();
			
			System.out.println(" escreva o valor do 3 lado");
			double lado3 = input.nextDouble();
		
		
			
			if =  
		
		

	}

}
