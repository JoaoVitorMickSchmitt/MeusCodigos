import java.util.Scanner;

public class switchcase2 {

	public static void main(String[] args) {
	
		
		Scanner input = new Scanner(System.in);
		
		
		System.out.println("diga o nome da fruta... ( a dica � banana e pera)");
		String fruta = input.next();
		
		
		switch (fruta) {
		
		case "banana":
			System.out.println("eu gosto de banana");
			break;
			
		case "pera":
			System.out.println("Eu n�o gosto dessa fruta");
			break;
		
		default :
			System.out.println("eu nao conhe�o essa fruta");
			break;
		}
		
		
		
		

	}

}
