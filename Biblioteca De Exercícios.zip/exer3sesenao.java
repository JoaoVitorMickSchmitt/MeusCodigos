import java.util.Scanner;

public class exer3sesenao {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		
		String str = input.next();
		
		String  nome = "joao";
		
		
				if (str.equalsIgnoreCase("joao")){System.out.println("voce acertou o nome");
			
		} else {System.out.println("voce errou o nome");

		}
		
	}

}
