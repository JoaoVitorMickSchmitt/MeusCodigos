import java.util.Scanner;

public class vetor4 {

	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		 
		
		int numeros[] = new int[100];
		
		
		
	for (int i = 0; i < 100; i++) {
		
		numeros[i] = i * i;
		System.out.println(" o quadrado do numero "+ i+ " e no vetor "+ i +" � "+ numeros[i]);
		
	}
		
		
		
		
		
		

	}

}
