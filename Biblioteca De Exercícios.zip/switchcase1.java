import java.util.Scanner;

public class switchcase1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		
		System.out.println("insira o numero 1  : ");
		double num = input.nextDouble();
	
		
		System.out.println("insira o numero 2  : ");
		double num2 = input.nextDouble();
		

		System.out.println("agora, insira o numero da ope��o 1 / 2 / 3 / 4  : ");
		int opera = input.nextInt();
		
		
		
		switch (opera) {
		
		case 1: 
			double soma = (num + num2);
			System.out.println(" o numero ser� "+ soma);
			break;
			
		case 2: 
			double menos = (num - num2);
			System.out.println(" o numero ser� "+ menos);
			break;
			
		case 3: 
			double multi = (num * num2);
			System.out.println(" o numero ser� "+ multi);
			break;
			
			
		case 4: 
			double divis�o = (num / num2);
			System.out.println(" o numero ser� "+ divis�o);
			break;
			
		
		}
		
		
		

	}

}
