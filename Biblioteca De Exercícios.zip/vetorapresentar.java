
public class vetor1 {

	public static void main(String[] args) {
	
		
		int idade[] = new int [4];
		
		
		idade[0] = 10
		
		
		
		
		

	}

}
