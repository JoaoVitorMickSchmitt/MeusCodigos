
public class exer1while {


	public static void main (String[] args) {
		int numer = 20;
		while(numer >= 10) {
		System.out.println(numer);
				numer--;
		}
		
		
		
		
		
		
	}
}
